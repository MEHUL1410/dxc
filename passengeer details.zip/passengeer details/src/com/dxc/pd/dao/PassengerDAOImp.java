package com.dxc.pd.dao;

import java.util.List;
import java.util.ArrayList;

import com.dxc.pd.model.Passenger;

public class PassengerDAOImp implements PassengerDAO {
	
	public PassengerDAOImp() {
		
	}
	
	List <Passenger>allPassenger = new ArrayList<Passenger>();
	@Override
	public Passenger getpnrNumber(int pnrNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Passenger> getAllPassenger() {
		// TODO Auto-generated method stub
		return allPassenger;
	}

	@Override
	public void addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
        allPassenger.add(passenger);
	}

	@Override
	public void deletePassenger(int pnrNumber) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePassenger(Passenger passenger) {
		// TODO Auto-generated method stub

	}

}
