package com.dxc.pd.dao;

import java.util.List;

import com.dxc.pd.model.Passenger;

public interface PassengerDAO {
	
	public Passenger getpnrNumber (int pnrNumber);
	public List<Passenger>getAllPassenger();
	public void addPassenger(Passenger passenger);
	public void deletePassenger(int pnrNumber);
	public void updatePassenger(Passenger passenger);

}
