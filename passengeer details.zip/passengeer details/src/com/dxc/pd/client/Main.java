package com.dxc.pd.client;

import java.util.Scanner;

import com.dxc.pd.model.Passenger;
import com.dxc.pd.dao.PassengerDAO;
import com.dxc.pd.dao.PassengerDAOImp;;

public class Main {

	public Main() {
		
	}
	
	public static void main(String[] args) {
		PassengerDAO passengerDAO = new PassengerDAOImp() ;
		
		while(true)
		{
			System.out.println("M E N U");
			System.out.println("1. Add The passenger : ");
            System.out.println("2. Get All passenger : ");
            System.out.println("3. E X I T");
            
            Scanner scanner = new Scanner(System.in);
            int choice = 0;
            System.out.println("please enter number between 1-3");
            choice = scanner.nextInt();
            
            switch(choice) {
            
            case 1:
            	System.out.println("please enter the pnr number:");
            	int pnrNumber = scanner.nextInt();
            	System.out.println("please enter passenger name:");
            	String passengerName = scanner.next();
            	System.out.println("please enter the source place:");
            	String source = scanner.next();
            	System.out.println("please enter the destination:");
            	String destination = scanner.next();
            	System.out.println("please enter fare:");
            	int fare = scanner.nextInt();
            	
            	Passenger passenger = new Passenger(pnrNumber,passengerName,source,destination,fare);
            	System.out.println(passenger);
            	
            	passengerDAO.addPassenger(passenger);
            	
            	break;
            	
            case 2 :
            	System.out.println(passengerDAO.getAllPassenger());
            	
            	break;
            	
            case 3 : 
            	System.out.println("thank u for using the program");
            	System.exit(0);
          
            default :
            	System.out.println("wrong, please enter between 1-3");
            }
            
            
			
		}
		
	}
}
