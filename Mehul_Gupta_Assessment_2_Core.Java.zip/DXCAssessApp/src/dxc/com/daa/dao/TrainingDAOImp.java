package dxc.com.daa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.daa.dbcon.DBConnection;
import com.dxc.daa.model.Training;

public class TrainingDAOImp implements TrainingDAO {
	Connection connection = DBConnection.getConnection();
	List<Training>allTrainings = new ArrayList<Training>();
	private static final String FETCH_TRAINING_ALL = "select * from training";
	private static final String RECORD_UPDATE_QUERY = "update training set percentage=? where SapId=?";

	public TrainingDAOImp() {
		super();
	}

	@Override
	public List<Training> displayrecords() {
		
		List<Training>allTrainings = new ArrayList<Training>();
		ResultSet res;
		
		try {
			Statement stat = connection.createStatement();
		  res = stat.executeQuery(FETCH_TRAINING_ALL);
		  while(res.next()) {
			  Training training = new Training();
				training.setSapId(res.getInt(1));
				training.setEmployeeName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allTrainings.add(training);
			   }
		}     catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allTrainings;


	}

	@Override
	public void updateTraining(int sapid, int percentage) {
		
		try {
			PreparedStatement preparedStatment  = connection.prepareStatement(RECORD_UPDATE_QUERY);
			preparedStatment.setInt(1,percentage);
			preparedStatment.setInt(2,sapid);
			preparedStatment.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}		
	}


