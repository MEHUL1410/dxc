package dxc.com.daa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.daa.dbcon.DBConnection;
import com.dxc.daa.model.Users;

public class UsersDAOImp implements UsersDAO {

	Connection connection = DBConnection.getConnection();
	
	private static final String FETCH_USERS_ALL = "select*from users";
	private static final String FETCH_USERS = "select * from users where username = ? and password = ?";
	
	@Override
	public boolean validate(String username, String password) {
		boolean userExists = false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(FETCH_USERS);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet res = preparedStatement.executeQuery();
			if(res.next()) {
				userExists = true;
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return userExists;
	}

	
}
