package dxc.com.daa.dao;

import com.dxc.daa.model.Users;

public interface UsersDAO {
	
	public boolean validate(String username,String password);
	

}
