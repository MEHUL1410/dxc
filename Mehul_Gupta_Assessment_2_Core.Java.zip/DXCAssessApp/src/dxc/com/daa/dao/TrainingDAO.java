package dxc.com.daa.dao;

import java.util.List;

import com.dxc.daa.model.Training;

public interface TrainingDAO {
	
	public List<Training>displayrecords();
	public void updateTraining( int sapid,int percentage);
}
