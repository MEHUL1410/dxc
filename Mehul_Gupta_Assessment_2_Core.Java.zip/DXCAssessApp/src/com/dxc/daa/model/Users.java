package com.dxc.daa.model;

public class Users {
	
	private String username;
	private String password;
	
	public Users() {
		super();
	}

	public Users(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public String getusername() {
		return username;
	}

	public void setusername(String username) {
		this.username = username;
	}

	public String getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Users [username=" + username + ", password=" + password + "]";
	}	
	
}


