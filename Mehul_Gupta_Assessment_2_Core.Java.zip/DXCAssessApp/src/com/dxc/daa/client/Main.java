package com.dxc.daa.client;

public class Main {
	
	 public Main() {
	        
	    }
	 public static void main(String[] args) {
		 
		 AssessApp app = new AssessApp();
		 app.launchAssessApp();
	 }	

}
