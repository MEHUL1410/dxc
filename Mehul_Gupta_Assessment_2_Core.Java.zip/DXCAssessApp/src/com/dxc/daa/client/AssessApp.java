package com.dxc.daa.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.dxc.daa.model.Training;

import dxc.com.daa.dao.TrainingDAO;
import dxc.com.daa.dao.TrainingDAOImp;
import dxc.com.daa.dao.UsersDAO;
import dxc.com.daa.dao.UsersDAOImp;

public class AssessApp {
	
	UsersDAO usersDAO;
	int choice = 0;
	String userName;
	String passWord;
	Scanner scanner = new Scanner(System.in);
	
	
		
		
		public void launchAssessApp() {
			UsersDAO usersDAO = new UsersDAOImp();
			
			System.out.println("please enter userName:");
			userName = scanner.next();
			System.out.println("please enter password");
			passWord = scanner.next();
			
			if (usersDAO.validate(userName, passWord)) {
				System.out.println("access granted");
			}
			else {
				System.out.println("invalid credential");
				System.exit(0);
			}
			 while (true) {
		            System.out.println("M E N U ");
		            System.out.println("1. Display All Training Records : ");
		            System.out.println("2. Display Records one by One and update the percentage : ");
		            System.out.println("3. E X I T ");
		            Scanner scanner = new Scanner(System.in);
		 
		            System.out.println("Please enter your choice : (1-3)");
		            choice = scanner.nextInt();
		            TrainingDAO trainingDAO = new TrainingDAOImp();
		 
		            switch (choice) {
		            case 1:
		 
		                System.out.println(trainingDAO.displayrecords());
		 
		                break;
		 
		            case 2:
		            	List<Training>record = new ArrayList<Training>();
		            	record = trainingDAO.displayrecords();
		            	Iterator<Training>iterator = record.iterator();
		            	
		            	while(iterator.hasNext()) {
		            		Training training = new Training();
		            		training = iterator.next();
		            		System.out.println(training.toString());
		            		if(training.getPercentage() == 0) {
		            			System.out.println("enter percentage:");
		            			int percentage = scanner.nextInt();
		            			trainingDAO.updateTraining(training.getSapId(),percentage);
		            			}
		            		else {
		            			System.out.println("percentage already enterd");
		            		}
		            	}
		            	
		            	
		                System.out.println("Welcome to training app Update");
		               
		                break;
		            }
			
		}
			 }
}
	
		
		


