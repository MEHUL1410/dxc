package com.dxc.pms.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Dealer;
import com.dxc.pms.model.User;
import com.dxc.pms.service.DealerService;
import com.dxc.pms.service.UserService;

@Repository
public class DealerDAOImpl implements DealerDAO {

	@Autowired
	UserService userService;
    DealerService dealerService;
	@Autowired
	MongoTemplate mongotemplate;
	DealerDAO dealerDAO;
	@Autowired
	UserDaoImpl daoImpl;
	
	//Create new dealer
	@Override
	public boolean addDealer(int userId,Dealer dealer) {
		// TODO Auto-generated method stub
		User user=userService.getUser(userId);
		System.out.println(user);
		user.setDealer(dealer);
		mongotemplate.save(user);
		mongotemplate.save(user.getDealer(),"dealer");
		return false;
	}
	
	//Get dealer by Id
	@Override
	public Dealer getDealer(int userId,int dealerId) {
		User user=userService.getUser(userId);
		System.out.println(user);
		Dealer r= user.getDealer();
		System.out.println(r);
			if(r.getDealerId()==dealerId) {
				return r;
			}
		return null;
	}
	@Override
	public Dealer getDealer(int dealerId) {
		return mongotemplate.findById(dealerId, Dealer.class,"dealer");
			
	}
	
	//Check whether the dealer is there or not
	 @Override
	    public boolean isDealerExists(int userId, int dealerId) {
		 
			User user=mongotemplate.findById(userId, User.class,"user");
			Dealer dealer=user.getDealer();
	        System.out.println(dealer);
	            if(dealer==null) {
	                return false;
	            }
	        return true;
	    }
	 
	 @Override
	    public boolean isDealerExists( int dealerId) {
			Dealer dealer=mongotemplate.findById(dealerId, Dealer.class,"dealer");
	        System.out.println(dealer);
	            if(dealer==null) {
	                return false;
	            }
	        return true;
	    }
	 
	 //Delete dealer by Id
	@Override
	public boolean deleteDealer(int userId,int dealerId)  {
		// TODO Auto-generated method stub
		//Deleting from the user database
		List<User> list=daoImpl.getAllUsers();
		System.out.println("Inside delete dealer");
		for(int i=0;i<list.size();i++) {
			System.out.println();
			if(!(list.get(i).getDealer()==null)) {
				if(list.get(i).getDealer().getDealerId()==dealerId) {
					list.get(i).setDealer(null);
				}	
			}
			
			mongotemplate.save(list.get(i));
		}         
         //Deleting from the dealer database    
		Dealer dealer=mongotemplate.findById(dealerId, Dealer.class,"dealer");
           mongotemplate.remove(dealer, "dealer");    
              return false;
	}
	
	//Update dealer
	 @Override
	    public boolean updateDealer(int userId, Dealer dealer) {
	  System.out.println("Inside dealer daoImpl");
			User user=userService.getUser(userId);
			user.setDealer(dealer);			
			mongotemplate.save(user.getDealer(), "dealer");
			mongotemplate.save(user, "user");
			return true;
}
	 
	 //Get all dealers
	@Override
	public List<Dealer> getAllDealer(int userId) {
		List<User> list=daoImpl.getAllUsers();
		List<Dealer> dealers=new ArrayList<Dealer>();
		System.out.println(list);
		for(int i=0;i<list.size();i++) {
			Dealer dealer=list.get(i).getDealer();
			dealers.add(dealer);	
			}
			System.out.println(dealers);
		return dealers;
	}

	//Get all dealers from dealer class
	@Override
	public List<Dealer> getAllDealer() {
		return mongotemplate.findAll(Dealer.class);
		
	}
	
	@Override
	public boolean isEmailExists(String email) {
		boolean res=false;
		List<Dealer> list=new ArrayList<Dealer>();
		System.out.println(mongotemplate.findAll(Dealer.class, "dealer"));
		System.out.println("Below is the value for list");
		list=mongotemplate.findAll(Dealer.class, "dealer");
		System.out.println(list);
		
		for(int i=0;i<list.size();i++) {
			
			System.out.println(list.get(i));
			if(list.get(i).getDealerEmail().equals(email)) {
				return res=true;	 
			}
		}
		return res;
	}
	
	public int login(String email) {
		int ID=0;
		List<Dealer> list=new ArrayList<Dealer>();
		list=mongotemplate.findAll(Dealer.class);
		System.out.println(list);
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i).getDealerEmail());
			System.out.println(email);
			if(list.get(i).getDealerEmail().equals(email)) {
				System.out.println("true");
				 ID=list.get(i).getDealerId();
			}
		}
		return ID;

}

	@Override
	public boolean addDealer(Dealer dealer) {
		System.out.println("Inside impl");
		System.out.println(dealer);
		mongotemplate.save(dealer, "dealer");
		
		return true;
		
		
	}

	@Override
	public List<User> history(int dealerID) {
	System.out.println("Inside history of users who have used this dealer with ID  "+dealerID);
	List<User> list=new ArrayList<User>();
	List<User> list1=new ArrayList<User>();
	list=mongotemplate.findAll(User.class, "user");
	System.out.println(list);
	for(int i=0;i<list.size();i++) {
		if(!(list.get(i).getDealer()==null)) {
			if(list.get(i).getDealer().getDealerId()==dealerID) {
				list1.add(list.get(i));
			
		}
		
			
			
		}
		}
		return list1;
	}
}
