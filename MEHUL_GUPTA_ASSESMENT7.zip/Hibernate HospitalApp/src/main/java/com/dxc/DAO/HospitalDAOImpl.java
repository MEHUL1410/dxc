package com.dxc.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.Hospital.util.HibernateUtil;

import com.entity.Doctor;

public class HospitalDAOImpl implements HospitalDAO {

	SessionFactory sf = HibernateUtil.getsSessionFactory();
	

	public List<Doctor> getAllDoctor() {
		Session session = sf.openSession();
		Query query = session.createQuery("from Doctor");
		return query.list();
	}

	public void addDoctor(Doctor doctor) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println("Doctor saved with name:"+ doctor.getDoctorName());
		
	}

	public void updateDoctor(Doctor doctor) {
		Session session =sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(doctor);
		transaction.commit();
		session.close();
		System.out.println("doctor updated with id:" + doctor.getDoctorId());
	}

	public Doctor getDoctor(String doctorName) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class, doctorName);
		return doctor;
	}

	public void deleteDoctor(int doctorId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = new Doctor();
		doctor.setDoctorId(doctorId);
		session.delete(doctor);
		transaction.commit();
		session.close();
		System.out.println("doctor deleted with id"+doctor.getDoctorId());
		
	}

}
