package com.dxc.DAO;

import java.util.List;


import com.entity.Doctor;

public interface HospitalDAO {
	
	
	public List<Doctor> getAllDoctor();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int doctorId);
	public void updateDoctor(Doctor doctor);
	public Doctor getDoctor(String doctorName);
}
