package com.entity;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
public class Doctor {
	@Id
	
	public int doctorId;
	public String doctorName;
	public int fees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails>hospitalDetails;
	
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Doctor(int doctorId, String doctorName, int fees) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
	}
	

	public Doctor(int doctorId, String doctorName, int fees, Set<HospitalDetails> hospitalDetails) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
		this.hospitalDetails = hospitalDetails;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}

	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + doctorId;
		result = prime * result + ((doctorName == null) ? 0 : doctorName.hashCode());
		result = prime * result + fees;
		result = prime * result + ((hospitalDetails == null) ? 0 : hospitalDetails.hashCode());
		return result;
	}

	

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", fees=" + fees + ", hospitalDetails="
				+ hospitalDetails + "]";
	}	

}
