package com.dxc.DAO;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.entity.Doctor;
import com.entity.HospitalDetails;

import junit.framework.TestCase;

public class HospitalDAOImplTest extends TestCase {
	
	HospitalDAOImpl impl;

	protected void setUp() throws Exception {
		
		impl = new HospitalDAOImpl();
	}

	protected void tearDown() throws Exception {
		impl = null; 
	}

	/*
	 * public void testGetAllDoctor() { int Data = impl.getAllDoctor().size();
	 * Doctor doctor = new Doctor(105, "jhon", 9000); impl.addDoctor(doctor); int
	 * Data2 = impl.getAllDoctor().size(); assertNotSame(Data2, Data); }
	 */
	/*
	 * public void testAddDoctor() { List<Doctor> doctors = impl.getAllDoctor();
	 * 
	 * Doctor doctor = new Doctor(100, "Vaibhav", 100); Set<HospitalDetails>
	 * hospitals = new HashSet<HospitalDetails>(); hospitals.add(new
	 * HospitalDetails("Ramaiah", "Bangalore"));
	 * doctor.setHospitalDetails(hospitals);
	 * 
	 * impl.addDoctor(doctor);
	 * 
	 * List<Doctor> testDoctors = impl.getAllDoctor();
	 * 
	 * impl.deleteDoctor(100); assertEquals(doctors.size() + 1, testDoctors.size());
	 * }
	 */

	/*
	 * public void testUpdateDoctor() { Doctor doctor = new Doctor(104, "jaya",
	 * 10000); impl.addDoctor(doctor); Doctor newDoctor = new Doctor(104, "ram",
	 * 5000); impl.updateDoctor(newDoctor); assertNotSame(newDoctor, doctor); }
	 */

	/*
	 * public void testGetDoctor() { Doctor doctor = new Doctor(103, "mehul",
	 * 20222); Set<HospitalDetails> hospitals = new HashSet<HospitalDetails>();
	 * hospitals.add(new HospitalDetails("raoHospital", "pune"));
	 * doctor.setHospitalDetails(hospitals); impl.addDoctor(doctor);
	 * 
	 * Doctor doctor2 = impl.getDoctor("mehul"); assertEquals(doctor, doctor2); }
	 */

	public void testDeleteDoctor() {
		Doctor doctor= new Doctor(); 
		int Data1 =  impl.getAllDoctor().size(); 
		impl.deleteDoctor(102);
		int Data2 = impl.getAllDoctor().size();
		assertNotSame(Data2, Data1);
	}

}
