package exercise;
import java.util.Scanner;


public class Product {
	
	int productId;
	
	int [] a = {111,112,113,114,115};
    String [] b = {"a","b","c","d","e"};
	int [] c= {500,200,300,150,350};
	int [] d  = {1,2,3,4,5};
	   
	 Scanner sc = new Scanner(System.in);
	
	public void display() {
		for (int j = 0;j<6;j++) {
			System.out.println("please enter productId");
			productId = sc.nextInt();
			
			if ( productId == a[0])
			{	
				System.out.println("[productId is " +a[0] +" "+ "productName is =" +b[0] +" " +"productPrice is = " +c[0] +" " +"productQuantity is = " +d[0] + " "+"]");
			}
			else if (productId == a[1]) 
			{
				System.out.println("[productId is = "+ a[1] +" "+"product name is = "+b[1] +" " +"productPrice is=" +c[1] + " " + "productQuantity is = "+d[1] +" "+" ]");
			}
			else if (productId == a[2])
			{
				System.out.println("[productId is = "+ a[2] +" "+"product name is = "+b[2] +" " +"productPrice is=" +c[2] + " " + "productQuantity is = "+d[2] + ""+"]");
			}
			else if (productId == a[3])
			{
				System.out.println("[productId is = "+ a[3] +" "+"product name is = "+b[3] +" " +"productPrice is=" +c[3] + " " + "productQuantity is = "+d[3] +" " +"]");
			}
			else if (productId == a[4])
			{
				System.out.println("[productId is = "+ a[4] +" "+"product name is = "+b[4] +" " +"productPrice is=" +c[4] + " " + "productQuantity is = "+d[4] +" " +"]");
			}
			else
			{
				System.out.println("product id is not available");
			}
	    }
	}
	
	public  static void main (String[] args)
	{
		 Product p = new Product();
		 p.display();
	}
	
}
