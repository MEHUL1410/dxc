package exercise;
import java.util.Scanner;


public class Example {
	Scanner sc= new Scanner(System.in);
	int productId;
	String productName;
	int productQuantity;
	int productPrice;

public void display()
{
	 for (int i=0;i<5;i++) {
	System.out.println();
	System.out.println("please enter the product Id :");
		productId = sc.nextInt();
	if (productId < 0)
	{
		System.out.println("negatives are not allowed");
	}
	
	else {
	
	System.out.println("please enter the product Name :");
	productName = sc.next();
	
	System.out.println("please enter the product Quantity :");
	productQuantity = sc.nextInt();
	
	if (productQuantity <0)
	{
		System.out.println("negatives are not allowed");
	}
	
	else {
	
	System.out.println("please enter the product Price :");
	productPrice = sc.nextInt();
	
	if (productPrice <0) 
	{
		System.out.println("negatives are not allowed");
	   }
	else {
		System.out.println ("[productId =" +productId +"  " +"productName =" +productName + " "+"productQuantity = " +productQuantity +" "+"productPrice ="+productPrice+" "+ "]");
	     }
	  }
	}
  }
}
	
	
	public static void main(String[] args)
	{
		Example p = new Example();
		p.display();
		
	}
}
	
