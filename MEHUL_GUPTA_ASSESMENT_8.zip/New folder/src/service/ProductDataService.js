import axios from 'axios';
const PRODUCT_API_URL = 'http://localhost:8001/product'
const SEARCH_API_URL = 'http://localhost:8001/product/name'
class ProductDataService
{
    getAllProducts(){
  return axios.get(`${PRODUCT_API_URL}`)
    }

    deleteProducts(productId){
        return axios.delete(`${PRODUCT_API_URL}/${productId}`)
          }
          getProducts(productId){
            return axios.get(`${PRODUCT_API_URL}/${productId}`)
              }
              updateProduct(product){
                return axios.put(`${PRODUCT_API_URL}/`, product)
              }
              saveProduct(product){
                return axios.post(`${PRODUCT_API_URL}/`, product)
              }

            searchProduct(productName){
                return axios.get(`${SEARCH_API_URL}/${productName}`)

            }  
}

export default new ProductDataService()