import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';

class DisplaySearch extends Component {

    constructor(props){
        super(props)
        this.state=({
            productName: this.props.match.params.prodName,
            products: []
        })
        this.getProduct=this.getProduct.bind(this);
        this.mainPage=this.mainPage.bind(this);
    }

    componentWillMount(product){
        this.getProduct();
        
    }
    getProduct(){
        ProductDataService.searchProduct(this.state.productName).then(response =>
                this.setState({
                products : response.data
            }))
    }

    mainPage(){
        this.props.history.push(`/products`)
    }

    

    render() {
        return (
            
            <div>
                <div className="container">
                    
                <h2>All Products For You</h2>
                <div className = "container" >
                    <table className = "container">
                        <thead>
                            <tr>
                            <th>product Id</th>
                            <th>product Name</th>
                            <th>quantity on hand</th>
                            <th>price</th>                
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.products.map( product =>

                            <tr key ={product.productId}>
                                <td>{product.productId}</td>
                                <td>{product.productName}</td>
                                <td>{product.quantityOnHand}</td>
                                <td>{product.price}</td>
                            </tr>
                            )}
                            </tbody>
                        </table>
                        <td>
                            <button className = "btn btn-primary" onClick= {this.mainPage}>Home</button>
                        </td>
                    </div>      
               </div> 
            </div>
            
        );
    }
}

    


export default DisplaySearch;