import React, { Component } from 'react';
import { Formik, Form,Field } from 'formik';
class SearchProductComponent extends Component {
    constructor(props){
        super(props)

        this.state=({ 
            
            productName:'',
          
        })
        this.onSubmit = this.onSubmit.bind(this);
    }
   
    onSubmit(product){
        console.log("on submit called")
    
                this.props.history.push(`/productsname/${product.productName}`)
            
        }

    
    render() {
       let { productName} = this.state 
        return (
            <div className = "container">
                
            <Formik
              initialValues={{  productName}}
              enableReinitialize="true" 
                onSubmit = {this.onSubmit}>
                <Form>
                <fieldset className="form-group">
                            <label>Product Name</label>
                               <Field className="form-control" type="text" name="productName" ></Field>
                        </fieldset>
                        <button className="btn btn-success" type = "submit">Search</button>
                </Form>
            </Formik>
          
                
            </div>
        );
    }
}

export default SearchProductComponent;