import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import { Formik, Form, Field, ErrorMessage } from 'formik'

class ProductComponent extends Component {

    constructor(props) {
        super(props);

        this.state = ({
            productId: this.props.match.params.prodId,
            productName: '',
            quantityOnHand: '',
            price: '',
            boolean: false
        })
        this.onSubmit=this.onSubmit.bind(this);
    }

    componentWillMount() {
        if(this.state.productId === "add")
        return;
        ProductDataService.getProducts(this.state.productId).then(
            response => {
                this.setState({
                    productName: response.data.productName,
                    quantityOnHand: response.data.quantityOnHand,
                    price: response.data.price,
                    boolean:true
                })
            }
        )
    }
    onSubmit(product) {
        if(this.state.productId === "add"){
            ProductDataService.saveProduct(product).then(
                response =>{
            this.props.history.push('/products')
                }
            ) }
        else{
        ProductDataService.updateProduct(product).then(()=>
        this.props.history.push('/products')
    )
    }
}
    validateProductForm(values){
        let errors={}
        if(!values.productId){
            errors.productId = 'enter a product id'
        }
        else if(!values.productName){
            errors.productName='enter a product name'
        }
        else if(!values.quantityOnHand){
            errors.quantityOnHand='enter quantity on hand'
        }
        else if(!values.price){
            errors.price='enter price'
        }
        else if(values.price<0){
            errors.price='price can not be negative'
        }
        else if(values.productName.length<5){
            errors.productName='name canm not be less than 5'
        }
        return errors
    }
    render() {

        let { productId, productName, quantityOnHand, price } = this.state
        return (
            <div className="container">
                <h3>add/update product </h3>
                <h4>a product to update</h4>
                {/* <h5>
               <div>productId: {productId}</div>
               <div>product Name: {productName}</div>
               <div>quantityOnHand: {quantityOnHand}</div>
               <div>price: {price}</div>
               </h5> */}
                <Formik
                    initialValues={{ productId, productName, quantityOnHand, price }}
                    enableReinitialize="true"
                    onSubmit={this.onSubmit}
                    validateOnChange={false}
                    validateOnBlur={false}
                    validate={this.validateProductForm}>
                    <Form>
                        <ErrorMessage name="productId" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="productName" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="quantityOnHand" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="price" component="div"
                        className = "alert alert-warning"></ErrorMessage>

                        <fieldset className="form-group">
                            <label>Product Id</label>
                               <Field className="form-control" type="text" name="productId" disabled = {this.state.boolean}></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName"></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Quantity on Hand </label>
                            <Field className="form-control" type="text" name="quantityOnHand"></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Price</label>
                            <Field className="form-control" type="text" name="price"></Field>
                        </fieldset>
                        <button className="btn btn-success" type="submit">Save</button>
                    </Form>
                </Formik>
            </div>
        );
    }
}

export default ProductComponent;