import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';


class ListProductComponent extends Component {
  
    constructor(props){
        super(props)
        this.refreshProduct = this.refreshProduct.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.updateProductClicked = this.updateProductClicked.bind(this);
        this.addProductClicked = this.addProductClicked.bind(this);
       this.searchProductClicked = this.searchProductClicked.bind(this);
        this.state = ({
            products : [],
            message : ''
        })
    }
    
    componentWillMount(){
            this.refreshProduct();
    }
     refreshProduct(){
       ProductDataService.getAllProducts().then(
          response => {this.setState  ({
                products : response.data
            });
        })
     }
     deleteButtonClicked(ProductIdToDelete){
        ProductDataService.deleteProducts(ProductIdToDelete).then(
            response =>
           {this.setState({
                message: `delete product ${ProductIdToDelete} successfully` })    
                this.refreshProduct();
             }
        )
     }
     addProductClicked(){
        this.props.history.push(`/productsadd/add`)
     }
     updateProductClicked(productId){
        this.props.history.push(`/productsadd/${productId}`)
     }
     searchProductClicked(){
            this.props.history.push(`/productsname`)
     }
    render() {
        return (
            <div>
                <div className="container">
                    {this.state.message &&
                    <div className ="alert alert-success">{this.state.message}</div>}
                <h2>All Products For You</h2>
                <div className = "container" >
                    <table className = "container">
                        <thead>
                            <tr>
                            <th>product Id</th>
                            <th>product Name</th>
                            <th>quantity on hand</th>
                            <th>price</th>
                            <th>update</th>
                            <th>delete</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.products.map( product =>

                            <tr key ={product.productId}>
                                <td>{product.productId}</td>
                                <td>{product.productName}</td>
                                <td>{product.quantityOnHand}</td>
                                <td>{product.price}</td>

                                <td><button className="btn btn-warning" onClick= {() => this.updateProductClicked(product.productId)}>update</button>
                                </td>

                                <td><button className="btn btn-danger" onClick= {() => this.deleteButtonClicked(product.productId)}>delete</button>
                                </td>
                            </tr>
                            )}
                            </tbody>
                        </table>
                        
                    </div>
                    
                  <td>
                    <button className="btn btn-success" onClick= {() => this.addProductClicked()}>Add</button>  
                    </td>
                    <td>
                    <button className="btn btn-primary" onClick= {() => this.searchProductClicked()}>Search</button>  
                    </td>
                     
                      
               </div> 
            </div>
            
        );
    }
}

export default ListProductComponent;