import React, { Component } from 'react';
import ListProductComponent from './components/ListProductComponent';
import 'bootstrap/dist/css/bootstrap.css'
import ProductComponent from './components/ProductComponent';
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import SearchProductComponent from './components/SearchProductComponent';
import DisplaySearch from './components/DisplaySearch';
class App extends Component {
  render() {
    return (
      <div>
        <h1>my product app</h1>

<Router>
  <Switch>
      <Route exact path ="/" component ={ListProductComponent}></Route>
      <Route exact path ="/products" component ={ListProductComponent}></Route>
      <Route exact path ="/productsadd/:prodId" component ={ProductComponent}></Route>
      <Route exact path ="/productsname" component={SearchProductComponent}></Route>
      <Route exact path ="/productsname/:prodName" component ={DisplaySearch}></Route>
      </Switch>
</Router>

   
      </div>
    );
  }
}

export default App;