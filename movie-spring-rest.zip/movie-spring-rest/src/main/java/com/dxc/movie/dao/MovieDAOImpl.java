package com.dxc.movie.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.movie.model.Movie;
import com.mongodb.WriteResult;

@Repository
public class MovieDAOImpl implements MovieDAO {
		
	@Autowired
	MongoTemplate mongotemplate;
		
	@Override
	public boolean addMovie(Movie movie) {
		System.out.println("movie inserted" +movie);
		mongotemplate.save(movie);
		return false;
	}

	@Override
	public Movie getMovie(int movieId) {
		
		return mongotemplate.findById(movieId, Movie.class, "movie");
	}

	@Override
	public List<Movie> getAllMovie() {
		return mongotemplate.findAll(Movie.class);
		 
	}

	@Override
	public boolean deleteMovie(int movieId) {
		
		Movie movie = new Movie();
		movie.setMovieId(movieId);
		WriteResult writeResult = mongotemplate.remove(movie);
		System.out.println(writeResult);
		int rowsAffected = writeResult.getN();
				if (rowsAffected == 0)
		return false;
				else
					return true;
		
	}

	@Override
	public boolean updateMovie(Movie movie) {
		
		 mongotemplate.save(movie);
		 return false;
	}

	@Override
	public boolean isMovieExist(int movieId) {
		Movie movie = mongotemplate.findById(movieId, Movie.class, "movie");
		if(movie == null)
		return false;
		else
			return true;
	}

}
