package com.dxc.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.dxc.movie.dao.MovieDAO;
import com.dxc.movie.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {
		@Autowired
		MovieDAO moviedao;
		
	@Override
	public boolean addMovie(Movie movie) {
	
		System.out.println("movie added: "+movie );
		moviedao.addMovie(movie);
	
		return false;
	}

	@Override
	public Movie getMovie(int movieId) {
		return moviedao.getMovie(movieId);
		
	}

	@Override
	public List<Movie> getAllMovie() {
		
		return moviedao.getAllMovie();
	}

	@Override
	public boolean deleteMovie(int movieId) {
		
		return moviedao.deleteMovie(movieId) ;
	}

	@Override
	public boolean updateMovie(Movie movie) {
		
		return moviedao.updateMovie(movie);
	}

	@Override
	public boolean isMovieExist(int movieId) {
		
		return moviedao.isMovieExist(movieId);
	}

}
