package com.dxc.movie.service;

import java.util.List;

import com.dxc.movie.model.Movie;

public interface MovieService {
	
	public boolean addMovie (Movie movie);
	public Movie getMovie(int movieId);
	public List<Movie> getAllMovie();
	public boolean deleteMovie(int movieId);
	public boolean updateMovie(Movie movie);
	public boolean isMovieExist(int movieId);

}
