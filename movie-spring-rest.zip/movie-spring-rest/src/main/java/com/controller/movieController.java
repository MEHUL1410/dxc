package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.movie.model.Movie;
import com.dxc.movie.service.MovieService;

@RestController
@RequestMapping("movie")

class movieController {
	
	@Autowired
	MovieService movieService;
	
	@GetMapping
	public List<Movie>getAllMovie(){
		System.out.println("all movies displayed");
		return movieService.getAllMovie();	
	}
	
	@GetMapping("/{movieId}")
	public Movie getMovie(@PathVariable("movieId")int movieId)
	{
		System.out.println("Movie displayed with movieid:" +movieId );
		return movieService.getMovie(movieId);
		
	}
	
	@PostMapping()
	public boolean saveMovie(@RequestBody Movie movie) {
		System.out.println("MOVIE SAVED: " +movie) ;
		
		return movieService.addMovie(movie);
	}	
	
	@PutMapping()
	public boolean updateMovie(@RequestBody Movie movie) {
		System.out.println("movie updated: "+movie);
		return movieService.updateMovie(movie);
		
	}
	
	@DeleteMapping("/{movieId}")
	public boolean deletedMovie(@PathVariable("movieId")int movieId) {
		System.out.println("movie deleted with id" +movieId);
		return movieService.deleteMovie(movieId);
		
	}
	
}
