import React, { Component } from 'react';
import { Formik, Form,Field,ErrorMessage } from 'formik';

class login extends Component {
    constructor(props){
        super(props)
    
        this.state = ({
            name: '',
            email:'',
            password:'',
            phone:'',
            pinCode:'',
            signUp:''
        })
    }
    validateForm(values){
      let errors={}
      if(!values.name){
          errors.name = 'please enter name'
      }
      else if(!values.email){
          errors.email='please enter email'
      }
      else if(!values.password){
          errors.password='please enter password'
      }
      else if(!values.phone){
          errors.phone='please enter your phone number'
      }
      else if(!values.pinCode){
          errors.pinCode='please enter pincode'
      }
      else if(!values.signUp){
          errors.signUp='please select any one'
      }
       if(values.password.length<6){
          errors.password="password should not be less than 6"
      }
      console.log(errors)
      return errors
    }
    render() {
        let { name, email, password, phone, pinCode,signUp } = this.state
      return (
        <div className="container"> 
          <h1>App</h1>
         
              <div>
                 
                  <Formik
                   initialValues={{ name, email, password, phone, pinCode,signUp }}
                  enableReinitialize = "true"
                  validateOnChange={false}
                  validateOnBlur={false}
                  validate ={this.validateForm}
                  onSubmit={this.onSubmit}
                  >
                   
                      <Form>

                      <ErrorMessage name="name" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="email" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="password" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="phone" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="pinCode" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="signUp" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        
                    


                      <fieldset className="form-group">
                              <label>Name</label>
                                 <Field className="form-control"  type="text" name="name" placeholder="enter your name"></Field>
                      </fieldset>
                          <fieldset className="form-group">
                              <label>Email</label>
                              <Field className="form-control" type="email" name="email"placeholder="enter your email"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Password </label>
                              <Field className="form-control" type="text" name="password" placeholder="enter your password"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Phone Number</label>
                              <Field className="form-control" type="text" name="phone" placeholder="enter your phone number"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Pincode</label>
                              <Field className="form-control" type="text" name="pinCode" placeholder = "enter pincode"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Sign up as</label>
                              <Field className="form-control"  as="select" name="signUp"  placeholder="please select">
                              <option value="dealer">Please select an option</option>
                              <option value="dealer">Dealer</option>
                                <option value="user">User</option>
                                
                            </Field>
                            
                          </fieldset>
         
                        <div>
                          <button className="btn btn-success" type="submit">Sign up</button>
                        </div> 
                      </Form>
                  </Formik>
                </div>
              </div>
      );
}
}

export default login;
