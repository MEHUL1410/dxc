import React, { Component } from 'react';
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import login from './components/login';
import 'bootstrap/dist/css/bootstrap.css'
import './App.css'




class App extends Component {
 
  render() {
    return (
      <div>
       <Router>
         <Switch>
         <Route exact path = "/" component = {login}></Route>
         </Switch>
       </Router>
      
        </div>
        );
  }
}
export default App;