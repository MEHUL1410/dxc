package com.controller;

import java.util.List;

import org.hibernate.validator.internal.util.privilegedactions.GetAnnotationParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins = {"http://localhost:3000","http://localhost:4200"})
public class productController {
	
	@Autowired
	ProductService prodocutService;
	
	
	// to fetch all the products
	
	@GetMapping
	public List<Product>getAllProducts(){
		System.out.println("fetching all products called");
		return prodocutService.getProducts();
	}
	
	// getting single product
	
	@GetMapping("/{prod}")
	public Product getProduct(@PathVariable("prod")int productId) {
		System.out.println("get product  1 called" +productId);
		return prodocutService.getProduct(productId);	
	}
	
	
	
	
	// delete single product
	
	@DeleteMapping("/{prodId}")
	public boolean deleteProduct(@PathVariable("prodId")int productId) {
		System.out.println("deleting product called with:" +productId);
		return prodocutService.deleteProduct(productId);	
	}
	
	// to save one product
		@PostMapping()
		public boolean saveProduct(@RequestBody Product product) {
			System.out.println("saving a product called");
			System.out.println(product);
			return prodocutService.addProduct(product);	
		}
		
		// to update one product
		@PutMapping()
		public boolean updateProduct(@RequestBody Product product) {
			System.out.println("updating a product called");
			System.out.println(product);
			return prodocutService.updateProduct(product);	
		}
	
	
	/*
	 * @RequestMapping("/getProduct") public Product getProduct() {
	 * System.out.println("get product called"); return
	 * prodocutService.getProduct(12);
	 * 
	 * 
	 * }
	 * 
	 * @RequestMapping("/getProduct/{productId}") public Product
	 * getProduct1(@PathVariable("productId")int productId) {
	 * System.out.println("get product 1 called"+productId); return
	 * prodocutService.getProduct(productId); }
	 * 
	 * @RequestMapping("/deleteProduct/{productId}") public Product
	 * deleProduct(@PathVariable("productId")int productId) {
	 * System.out.println("deleting product called"+productId); return
	 * prodocutService.getProduct(productId); }
	 */
	
	@RequestMapping("/getProduct/{productId}/order/{oId}")
	public Product getProduct2(@PathVariable("productId")int productId,@PathVariable("oId")int orderid) {
		System.out.println("get product 2 called"+productId +"orderid:"+orderid);
		return prodocutService.getProduct(productId);	
	}
	
	@RequestMapping("/getProduct/pp")
	public Product getProduct3() {
		System.out.println("get product 3 called");
		return prodocutService.getProduct(44);	
	}
	
	/*
	 * @RequestMapping("/productSave") public ModelAndView productSave(Product
	 * product) {
	 * 
	 * System.out.println("inside controller:"+product);
	 * prodocutService.addProduct(product); return new
	 * ModelAndView("success","p",product);
	 * 
	 * }
	 */

}
