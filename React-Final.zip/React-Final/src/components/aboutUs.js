import React, { Component } from 'react';
import { SocialIcon } from 'react-social-icons';
import logo from './logo.jpg'
import'./aboutUs.css'

class aboutUs extends Component {
    render() {
        return (
            <div>
                 <header className="header">
          <nav className="navbar navbar-style">
          <div className="container" id="c1">
                  <div className="navbar-header">
                     <img src={logo} class="logo1" alt="not found"></img> 
                  </div>{
                   <h1 id="h1">Vehicle Maintenance App</h1>} 
                  <div className= "nav ">
                      <a href ="/login">home</a>
                      <a href ="">contact</a>
                      <a href ="/aboutUs">about us</a>
                      
                  </div>
             </div>
          </nav>
      </header>
                
              <title><h1>Vehicle Maintenance Log</h1></title>
              <h1 id="home">Vehicle Maintenance Log</h1>
               <p id = "about">We are doing the best vehicle Maintenance log on the web!!Signup for free Vehicle
                   Maintenance Tracking and make use of the best service that we offer!</p> 
                <h1 id="home">Everything you need to track Vehicle Maintenance</h1>
                <h1 id="home">Our Features</h1>
                <h2 id="home">Vehicle Maintenance tracking made easy!</h2>
                <p id="about"> Register your vehicle and start logging maintenance records..Enter the maintenance
                    type and get the service very easily.
                </p>
                <h2 id="home">Easy to grab the vehicle Maintenance records!</h2>
                <p id="about">Here is the detailed car maintenance history for the potential buyers and for the analysis.</p>
                <h2 id="home">Send E-mail reminders to The Dealers</h2>
                <p id="about">No need to worry during the emergency.Fix the problems very easily by sending the e-mail
                    to the dealers.Send e-mail whenever the Vehicle needs Service and fix the appointment
                    very easily.
                </p>
                <title>About Us</title>
                <h2 id="home">Why to use Vehicle Maintenance tracking in our website</h2>
                <p id="about">We are giving the best web-based vehicle management solution that makes keeping track of vehicle maintenance records simple and paper-free. Writing down the last time one of your vehicles had an oil change or a tire rotation – and the next time it is due for service – can be a time-consuming and inefficient process.
                     However, paying for an expensive fleet management system is not always the answer either 
                     – especially when you only need to keep track of maintenance records for a personal vehicle 
                     or a small fleet for your business.Here,the signing up and registering
                      your first vehicle is free and always will be.
                       Upon logging into your account, adding new maintenance and repair 
                       records is as easy as a few clicks of a button. 
                       Simply enter the maintenance or repair information, click submit,
                     and the new record will be added to the vehicle maintenance log.</p>
                  <p id="about">During emergency when your vehicle encounters a sudden breakdown,
                   You can easily set the e-mail to the dealer. </p>
                   <p id="about">Since we’re a web-based vehicle maintenance and management software 
                       solution, we’re always hard at work making improvements to our website by 
                       rolling out new features that help you management or personal vehicle or 
                       small fleet. If you have any questions or recommendations on 
                       how to improve our website, let us know – we’d love to hear from you!</p>
                       
                       <footer className="footer3">
            &copy; Copyright: <a href="">Vehicle Maintenance</a>
                <div className = "footer-icons">
                <SocialIcon url="https://www.facebook.com/"  />
                <SocialIcon url="https://www.instagram.com/?hl=en"  />
                <SocialIcon url="https://twitter.com/login"  />
                <SocialIcon url="https://www.whatsapp.com/"  />
             
                </div>
            </footer>
            </div>
        );
    }
}

export default aboutUs;