package exercise;

public class Road {

	public static void main(String[] args) {
		Truck t = new Truck("black", 16,"trc12" );
		t.setNumberOfSeats(2);
		t.setStorageCapacity(1000);
		System.out.println(t);
		
		Bus b = new Bus("white", 8, "bus34");
		b.setBusType("volvo");
        b.setNumberOfSeats(50);	
        System.out.println(b);
        
        Car c = new Car("blue", 4, "car77");
        c.setNumberOfDoor(4);
        c.setNumberOfGears(5);
        
		System.out.println(c);
				
				

	}

}
