package exercise;

public class Vehicle {
	private String color;
	private int numberOfWheels;
	private String model;
	
	
	


	public Vehicle() {
		super();
	}
	
	public Vehicle(String color, int numberOfWheels, String model) {
		
		this.color = color;
		this.numberOfWheels = numberOfWheels;
		this.model = model;
	}

	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public int getNumberOfWheels() {
		return numberOfWheels;
	}


	public void setNumberOfWheels(int numberOfWheels) {
		this.numberOfWheels = numberOfWheels;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	@Override
	public String toString() {
		return "Vehicle [ color=" + color + ", numberOfWheels="	+ numberOfWheels + ", model=" + model + "]";
	}
	
	
	
	
	

}
