package exercise;

public class Bus extends Vehicle {
	
	private int numberOfSeats;
	private String busType;


	public Bus() {
		super();
	}
	public Bus(String color, int numberOfWheels, String model) {
		super(color, numberOfWheels, model);
		// TODO Auto-generated constructor stub
	}
	

	public Bus(int numberOfSeats, String busType) {
		super();
		this.numberOfSeats = numberOfSeats;
		this.busType = busType;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	@Override
	public String toString() {
		return "Bus [numberOfSeats=" + numberOfSeats + ", busType=" + busType + ", getColor()=" + getColor()
				+ ", getNumberOfWheels()=" + getNumberOfWheels() + ", getModel()=" + getModel() + "]";
	}

	

}
