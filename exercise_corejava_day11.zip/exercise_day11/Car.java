package exercise;

public class Car extends Vehicle {
	
	private int numberOfDoor;
	private int numberOfGears;
	

	public Car() {
		// TODO Auto-generated constructor stub
	}


	public Car(String color, int numberOfWheels, String model) {
		super(color, numberOfWheels, model);
		// TODO Auto-generated constructor stub
	}


	public Car(int numberOfDoor, int numberOfGears) {
		super();
		this.numberOfDoor = numberOfDoor;
		this.numberOfGears = numberOfGears;
	}


	public int getNumberOfDoor() {
		return numberOfDoor;
	}


	public void setNumberOfDoor(int numberOfDoor) {
		this.numberOfDoor = numberOfDoor;
	}


	public int getNumberOfGears() {
		return numberOfGears;
	}


	public void setNumberOfGears(int numberOfGears) {
		this.numberOfGears = numberOfGears;
	}


	@Override
	public String toString() {
		return "Car [numberOfDoor=" + numberOfDoor + ", numberOfGears=" + numberOfGears + ", getColor()=" + getColor()
				+ ", getNumberOfWheels()=" + getNumberOfWheels() + ", getModel()=" + getModel() + "]";
	}

}
