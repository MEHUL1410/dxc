package exercise;

public class Truck extends Vehicle {
	
	private int storageCapacity;
	private int numberOfSeats;
	
	

	public Truck() {
		super();
	}

	public Truck(String color, int numberOfWheels, String model) {
		super(color, numberOfWheels, model);
		// TODO Auto-generated constructor stub
	}

	public Truck(int storageCapacity, int numberOfSeats) {
		super();
		this.storageCapacity = storageCapacity;
		this.numberOfSeats = numberOfSeats;
	}

	public int getStorageCapacity() {
		return storageCapacity;
	}

	public void setStorageCapacity(int storageCapacity) {
		this.storageCapacity = storageCapacity;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	@Override
	public String toString() {
		return "Truck [storageCapacity=" + storageCapacity + ", numberOfSeats=" + numberOfSeats + ", getColor()="
				+ getColor() + ", getNumberOfWheels()=" + getNumberOfWheels() + ", getModel()=" + getModel() + "]";
	}

	
	

}
